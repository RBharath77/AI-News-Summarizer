import os
import uuid
import time
from utils.news_fetcher import fetch_news
import yaml
import feedparser
import subprocess
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from gtts import gTTS

from utils.summarizer import summarize_text
from utils.translate import translate_text
from utils.news_fetcher import fetch_news  # <-- for /summarize route

load_dotenv()
app = Flask(__name__, static_folder="static", template_folder="templates")
AUDIO_DIR = os.path.join("static", "audio")
os.makedirs(AUDIO_DIR, exist_ok=True)

# -----------------------------
# Voice synthesis helpers
# -----------------------------
def _macos_say(text, voice, out_basename):
    outfile = f"{out_basename}.m4a"
    cmd = ["say", "-v", voice, "-o", outfile, text]
    subprocess.call(cmd)
    return outfile

def _gtts_say(text, lang, out_basename):
    outfile = f"{out_basename}.mp3"
    tts = gTTS(text=text, lang=lang)
    tts.save(outfile)
    return outfile

def synthesize_speech(text: str, voice_id: str, out_basename: str) -> str:
    if voice_id.startswith("macos:"):
        voice = voice_id.split(":", 1)[1]
        try:
            return _macos_say(text, voice, out_basename)
        except Exception:
            return _gtts_say(text, "en", out_basename)
    elif voice_id.startswith("gtts:"):
        lang = voice_id.split(":", 1)[1]
        return _gtts_say(text, lang, out_basename)
    else:
        return _gtts_say(text, "en", out_basename)

# -----------------------------
# Load RSS sources
# -----------------------------
with open("news_sources.yaml", "r", encoding="utf-8") as f:
    NEWS_SOURCES = yaml.safe_load(f)

_FEED_CACHE = {}
_CACHE_TTL = 180  # seconds

def fetch_feed(url):
    now = time.time()
    cached = _FEED_CACHE.get(url)
    if cached and now - cached["t"] < _CACHE_TTL:
        return cached["data"]
    parsed = feedparser.parse(url)
    _FEED_CACHE[url] = {"t": now, "data": parsed}
    return parsed

# -----------------------------
# Backend: Language + Voice options
# -----------------------------
language_voices = [
    {"code": "ta", "voice_id": "gtts:ta", "name": "Tamil"},
    {"code": "en", "voice_id": "gtts:en", "name": "English"},
    {"code": "hi", "voice_id": "gtts:hi", "name": "Hindi"},
    {"code": "te", "voice_id": "gtts:te", "name": "Telugu"},
    {"code": "kn", "voice_id": "gtts:kn", "name": "Kannada"},
    {"code": "ml", "voice_id": "gtts:ml", "name": "Malayalam"},
    {"code": "mr", "voice_id": "gtts:mr", "name": "Marathi"},
    {"code": "bn", "voice_id": "gtts:bn", "name": "Bengali"},
    {"code": "gu", "voice_id": "gtts:gu", "name": "Gujarati"},
    {"code": "pa", "voice_id": "gtts:pa", "name": "Punjabi"},
]

# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def index():
    return render_template(
        "index.html",
        sources=NEWS_SOURCES,
        language_voices=language_voices
    )

# -----------------------------
# API: Get news from RSS feeds
# -----------------------------
@app.route("/api/news", methods=["POST"])
def api_news():
    data = request.get_json(force=True)
    source_key = data.get("source_key")
    max_items = int(data.get("max_items", 5))
    source = NEWS_SOURCES.get(source_key)
    if not source:
        return jsonify({"ok": False, "error": "Invalid source"}), 400
    parsed = fetch_feed(source["url"])
    items = []
    for entry in parsed.entries[:max_items]:
        items.append({
            "title": entry.get("title", ""),
            "link": entry.get("link", ""),
            "summary_hint": entry.get("summary", "")[:500],
            "published": entry.get("published", "")
        })
    return jsonify({"ok": True, "items": items})

# -----------------------------
# API: Summarize + Translate
# -----------------------------
@app.route("/api/summarize", methods=["POST"])
def api_summarize():
    payload = request.get_json(force=True)
    text = payload.get("text", "")
    target_lang = payload.get("target_lang", "en")
    if not text.strip():
        return jsonify({"ok": False, "error": "Empty text"}), 400
    summary_en = summarize_text(text)
    if target_lang != "en":
        summary_out = translate_text(summary_en, target_lang)
    else:
        summary_out = summary_en
    return jsonify({"ok": True, "summary": summary_out})

# -----------------------------
# API: Text-to-speech
# -----------------------------
@app.route("/api/voice", methods=["POST"])
def api_voice():
    payload = request.get_json(force=True)
    text = payload.get("text", "")
    voice_id = payload.get("voice_id", "gtts:en")
    if not text.strip():
        return jsonify({"ok": False, "error": "Empty text"}), 400
    fname = f"{uuid.uuid4().hex}"
    out_path = os.path.join(AUDIO_DIR, fname)
    audio_file = synthesize_speech(text, voice_id, out_path)
    return jsonify({"ok": True, "url": f"/static/audio/{os.path.basename(audio_file)}"})

# -----------------------------
# Health check
# -----------------------------
@app.route("/health")
def health():
    return jsonify({"ok": True, "status": "running"})

# -----------------------------
# Run app
# -----------------------------
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
