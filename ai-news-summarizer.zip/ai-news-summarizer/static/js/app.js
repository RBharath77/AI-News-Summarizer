// -----------------------------
// Constants / DOM elements
// -----------------------------
document.addEventListener("DOMContentLoaded", () => {
    const newsContainer = document.getElementById("newsContainer");
    const sourceSel = document.getElementById("source");
    const maxItems = document.getElementById("maxItems");
    const fetchBtn = document.getElementById("fetchBtn");
    const langVoiceSelect = document.getElementById("languageVoice");

    const ENDPOINT_NEWS = "/api/news";
    const ENDPOINT_SUMMARIZE = "/api/summarize";
    const ENDPOINT_VOICE = "/api/voice";

    if (!newsContainer || !sourceSel || !maxItems || !fetchBtn || !langVoiceSelect) {
        console.error("One or more DOM elements not found. Check IDs!");
        return;
    }

    // -----------------------------
    // Skeleton loader
    // -----------------------------
    function cardSkeleton() {
        return `
        <div class="p-4 bg-white rounded-2xl shadow-sm animate-pulse">
            <div class="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
            <div class="h-3 bg-slate-200 rounded w-full mb-1"></div>
            <div class="h-3 bg-slate-200 rounded w-5/6"></div>
        </div>
        `;
    }

    // -----------------------------
    // News card template
    // -----------------------------
    function newsCard(item, summary, audioUrl) {
        const safeTitle = item.title || "Untitled";
        return `
        <div class="p-4 bg-white rounded-2xl shadow-sm">
            <a class="text-lg font-semibold hover:underline" href="${item.link}" target="_blank">${safeTitle}</a>
            <p class="text-xs text-slate-500 mt-1">${item.published || ""}</p>
            <p class="mt-3">${summary}</p>
            <div class="mt-3 flex items-center gap-3">
                ${audioUrl ? `<audio controls src="${audioUrl}" class="w-full"></audio>` : ""}
            </div>
        </div>
        `;
    }

    // -----------------------------
    // POST JSON helper
    // -----------------------------
    async function postJSON(url, body) {
        const res = await fetch(url, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(body)
        });
        if (!res.ok) throw new Error(await res.text());
        return res.json();
    }

    // -----------------------------
    // Handle fetch news button click
    // -----------------------------
    fetchBtn.addEventListener("click", async () => {
        newsContainer.innerHTML = cardSkeleton() + cardSkeleton() + cardSkeleton();

        try {
            const source_key = sourceSel.value;
            const itemsResp = await postJSON(ENDPOINT_NEWS, {
                source_key,
                max_items: parseInt(maxItems.value || "5", 10)
            });

            if (!itemsResp.ok) throw new Error(itemsResp.error || "Failed to fetch news");

            const [target_lang, voice_id] = langVoiceSelect.value.split("|");

            newsContainer.innerHTML = "";
            for (const item of itemsResp.items) {
                const text = (item.title || "") + ". " + (item.summary_hint || "");
                const sumResp = await postJSON(ENDPOINT_SUMMARIZE, { text, target_lang });
                if (!sumResp.ok) throw new Error(sumResp.error || "Failed to summarize");

                let audioUrl = null;
                try {
                    const voiceResp = await postJSON(ENDPOINT_VOICE, { text: sumResp.summary, voice_id });
                    if (voiceResp.ok) audioUrl = voiceResp.url;
                } catch (e) {
                    console.warn("TTS error:", e.message);
                }

                newsContainer.insertAdjacentHTML("beforeend", newsCard(item, sumResp.summary, audioUrl));
            }
        } catch (err) {
            newsContainer.innerHTML = `
            <div class="p-4 bg-red-50 border border-red-200 rounded-2xl">
                <div class="font-semibold text-red-700">Error</div>
                <div class="text-sm text-red-600">${err.message}</div>
            </div>
            `;
        }
    });

    // -----------------------------
    // Log changes on Language & Voice dropdown
    // -----------------------------
    langVoiceSelect.addEventListener("change", () => {
        const [selectedLanguage, selectedVoice] = langVoiceSelect.value.split("|");
        console.log("Selected Language:", selectedLanguage);
        console.log("Selected Voice:", selectedVoice);
    });
});
