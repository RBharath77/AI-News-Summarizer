import os
import yaml
from datetime import datetime
from newsapi import NewsApiClient

# Load API key
NEWSAPI_KEY = os.getenv("NEWSAPI_KEY")
newsapi = NewsApiClient(api_key=NEWSAPI_KEY)


def load_topics_from_yaml(path="source_news.yaml"):
    """Load list of topics from YAML file."""
    with open(path, "r") as f:
        data = yaml.safe_load(f)
    return data.get("topics", [])


def fetch_news(count=5):
    """Fetch today's trending news across all topics, but show only top N results."""
    
    topics = load_topics_from_yaml()
    today = datetime.now().strftime("%Y-%m-%d")

    final_news = []
    seen_titles = set()

    INTERNAL_FETCH_LIMIT = count * 10     # we fetch MORE internally to ensure enough results

    for topic in topics:
        try:
            response = newsapi.get_everything(
                q=topic,
                language="en",
                from_param=today,
                to=today,
                sort_by="publishedAt",
                page_size=20
            )

            for article in response.get("articles", []):
                title = article.get("title", "").strip()
                content = article.get("content", "")

                if title and content and title not in seen_titles:
                    seen_titles.add(title)
                    final_news.append(article)

                # Stop once enough articles collected
                if len(final_news) >= INTERNAL_FETCH_LIMIT:
                    break

        except Exception as e:
            print(f"⚠ Error fetching '{topic}': {e}")

    # Sort by latest time
    final_news.sort(key=lambda x: x.get("publishedAt", ""), reverse=True)

    # Return exactly count items
    return final_news[:count]
