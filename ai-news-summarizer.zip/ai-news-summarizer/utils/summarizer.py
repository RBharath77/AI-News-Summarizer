import re
import requests
from bs4 import BeautifulSoup
from transformers import pipeline
from newspaper import Article

# Load summarization model once
summarizer_model = pipeline("summarization", model="facebook/bart-large-cnn")

def clean_text(text: str) -> str:
    """Clean and normalize text."""
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\[[^\]]*\]', '', text)
    return text.strip()

def fetch_full_article(url: str) -> str:
    """Try fetching full article text with multiple methods."""
    # 1️⃣ Try newspaper3k
    try:
        article = Article(url)
        article.download()
        article.parse()
        text = clean_text(article.text)
        if len(text.split()) > 80:
            return text
    except Exception:
        pass

    # 2️⃣ Fallback: requests + BeautifulSoup
    try:
        r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        soup = BeautifulSoup(r.text, "html.parser")
        paragraphs = [p.get_text() for p in soup.find_all("p")]
        text = clean_text(" ".join(paragraphs))
        if len(text.split()) > 80:
            return text
    except Exception:
        pass

    # 3️⃣ If still short
    return ""

def summarize_text(text: str, url: str = None) -> str:
    """Summarize text with fallback for short or missing content."""
    try:
        # Try to fetch full content
        if url:
            full_text = fetch_full_article(url)
            if len(full_text) > len(text):
                text = full_text

        text = clean_text(text)

        # If content too short → return readable message
        if not text or len(text.split()) < 40:
            headline = text if len(text.split()) > 0 else "This article"
            return f"'{headline}' — The article content is too short or restricted for summarization. Please visit the source for full details."

        # Split large text into chunks
        max_chunk = 1000
        paragraphs = []
        for i in range(0, len(text), max_chunk):
            chunk = text[i:i+max_chunk]
            summary_chunk = summarizer_model(
                chunk, max_length=150, min_length=40, do_sample=False
            )[0]['summary_text']
            paragraphs.append(summary_chunk)

        summary = " ".join(paragraphs)
        summary = re.sub(r'\*\*', '', summary).strip()

        # Ensure output has at least 2 lines
        if len(summary.split('.')) < 2:
            summary += " This news article had limited content, so the summary may be brief."

        return summary

    except Exception as e:
        print(f"[Summarizer error] {e}")
        return "Unable to summarize this article at the moment. Please try again later."
