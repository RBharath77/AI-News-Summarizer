import os
import subprocess
from gtts import gTTS
# inside tts/__init__.py
from gtts import gTTS
import os

def _gtts_say(text: str, lang: str, out_basename: str) -> str:
    mp3_path = f"{out_basename}.mp3"
    tts = gTTS(text=text, lang=lang)
    tts.save(mp3_path)
    return mp3_path

def _macos_say(text: str, voice: str, out_basename: str) -> str:
    mp3_path = f"{out_basename}.mp3"
    aiff_path = f"{out_basename}.aiff"

    subprocess.run(["say", "-v", voice, "-o", aiff_path, text], check=True)
    subprocess.run(["afconvert", aiff_path, mp3_path, "-f", "WAVE", "-d", "LEI16"], check=True)

    try:
        os.remove(aiff_path)
    except Exception:
        pass
    return mp3_path

def _gtts_say(text: str, lang: str, out_basename: str) -> str:
    mp3_path = f"{out_basename}.mp3"
    tts = gTTS(text=text, lang=lang)
    tts.save(mp3_path)
    return mp3_path

def synthesize_speech(text: str, voice_id: str, out_basename: str) -> str:
    """
    voice_id:
      - 'macos:Alex', 'macos:Samantha', 'macos:Daniel', 'macos:Veena', etc.
      - 'gtts:en', 'gtts:hi', 'gtts:ta', ...
    """
    if voice_id.startswith("macos:"):
        voice = voice_id.split(":", 1)[1]
        try:
            return _macos_say(text, voice, out_basename)
        except Exception:
            # fallback to English gTTS if macOS voice fails
            return _gtts_say(text, "en", out_basename)
    elif voice_id.startswith("gtts:"):
        lang = voice_id.split(":", 1)[1]
        return _gtts_say(text, lang, out_basename)
    else:
        # default fallback
        return _gtts_say(text, "en", out_basename)
